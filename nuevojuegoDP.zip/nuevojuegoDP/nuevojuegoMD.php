<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class nuevojuegoMD extends Model
{
    public $timestamps=false;
    protected $table="nuevojuego";
    protected $fillable= array('id','nickjugador','level';
}
