<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\nuevojuegoMD;

class nuevojuegoDP extends Controller
{
  public function index ()
  {
    return \App\nuevojuegoMD::all();
  }
  public function show ($id)
  {
    return \App\nuevojuegoMD::find($id);
  }
  public function store (Request $request)
  {
    //$objeto->campo=$
    return \App\nuevojuegoMD::create($request->all());
  }
  public function update (Request $request, $id)
  {
    $registro=\App\nuevojuegoMD::findOrFail($id);
    $registro->update($request->all());

    //return \App\nuevojuegoMD::update($request->all());

    return $registro;
  }
  public function destroy ($id)
  {
    $registro=\App\nuevojuegoMD::findOrFail($id);
    $registro->delete();

    return 204;//indicaa el resultado cuando se toma una accion en internet en este caso 204 confirma que este programa proceso correctamente
  }
}
